﻿using System;

namespace ConsoleApp3
{
    class Program
    {
        #region part1
        //part 1 direction
        //Create an enumerable type named 'Directions' containing all 4 directions north, south, east and west.
        enum Directions
        {
            North,
            East,
            South,
            West
        }
        #endregion
        static void Main(string[] args)
        {
            #region part2
            // 1. Declare a variable named 'playerDirection' of the enum 'Directions' type.
            //2. Ask the user to input one of the available directions.
            //3. Use an if statment to check the input and display a different message for every possible option.
            Console.WriteLine("chose an direction 0 = North, 1 = East, 2 = South, 3 = West");
            int enumID = Convert.ToInt32(Console.ReadLine());
            Directions chosendir = (Directions)enumID;
            if (chosendir == Directions.North)
            {
                Console.WriteLine("U picked North");
            }
            if (chosendir == Directions.East)
            {
                Console.WriteLine("U picked East");
            }
            if (chosendir == Directions.South)
            {
                Console.WriteLine("U picked South");
            }
            if (chosendir == Directions.West)
            {
                Console.WriteLine("U picked West");
            }

        }
        #endregion
    }
}
    